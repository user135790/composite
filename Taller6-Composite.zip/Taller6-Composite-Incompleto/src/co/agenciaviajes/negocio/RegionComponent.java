package co.agenciaviajes.negocio;

import java.util.ArrayList;

/**
 * Representa una region del planeta, como continente o pais
 *
 * @author Libardo Pantoja, Ricardo Zambrano, Julio Hurtado
 */
public class RegionComponent extends PaqueteComponent {

    public ArrayList<PaqueteComponent> regionContenido = new ArrayList();

    // Complete constructor

    public RegionComponent(String nombre) {
        super(nombre);
    }
    
    
    @Override
    public long getComponentPrecio() {
        long precioOfAllHojas = 0;

        for (Object component : regionContenido) {
            precioOfAllHojas = precioOfAllHojas + (((PaqueteComponent) component).getComponentPrecio());
        }
        return precioOfAllHojas;
    }
    public void RegionComponent(String nombre) {
        this.nombre = nombre;
    }
    @Override
    public void addComponent(PaqueteComponent fc) throws Exception {
        regionContenido.add(fc);
        // throw new Exception("Invalid Operation. Not Supported");
    }
    @Override
    public PaqueteComponent getComponent(int location) throws Exception {
       //throw new Exception("Invalid Operation. Not Supported");

            return (PaqueteComponent) regionContenido.get(location);
    
    }

    
    // Complete demas  metodos
}
